(*
  Contents of archive:
    readme.txt
    which_shape.caml
    alex9-sde2.log

  Pledge:
    On my honor I have neither given nor received aid on this
    exam
    SIGN: Alex Moore

*)
